import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow GET requests
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.VITE_CRYPTOPANIC_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'Server configuration error: API key missing' });
  }

  try {
    // Construct the URL with the server-side API key
    const apiUrl = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
    
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      return res.status(response.status).json({ 
        error: `Upstream API error: ${response.statusText}`,
        detail: await response.text() 
      });
    }

    const data = await response.json();
    
    // Set cache control headers for performance (cache for 10 minutes)
    res.setHeader('Cache-Control', 's-maxage=600, stale-while-revalidate');
    
    return res.status(200).json(data);
  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
