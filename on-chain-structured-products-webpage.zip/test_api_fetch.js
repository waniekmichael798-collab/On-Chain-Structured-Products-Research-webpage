// test-api.js — Run with: node test-api.js

const API_KEY = "a995abdab0baff97b69234d859877f8e783994e8"; // Hardcoded for test
const TEST_URL = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${API_KEY}&public=true&kind=news`;

console.log("=== ISOLATED API TEST ===");
console.log("URL:", TEST_URL);

fetch(TEST_URL)
  .then(response => {
    console.log("STATUS:", response.status);
    console.log("STATUS TEXT:", response.statusText);
    // Node.js fetch headers might need different handling than browser, but this is standard
    // console.log("HEADERS:", Object.fromEntries(response.headers.entries())); 
    return response.json();
  })
  .then(data => {
    console.log("SUCCESS - Results count:", data.results?.length);
    console.log("First item title:", data.results?.[0]?.title);
  })
  .catch(error => {
    console.log("ERROR TYPE:", error.name);
    console.log("ERROR MESSAGE:", error.message);
    if (error.cause) console.log("CAUSE:", error.cause);
  });
