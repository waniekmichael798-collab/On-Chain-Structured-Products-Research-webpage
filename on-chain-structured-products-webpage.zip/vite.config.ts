import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "path";
import { defineConfig } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";

const plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime()];

export default defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port: 3000,
    strictPort: false, // Will find next available port if 3000 is busy
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1",
    ],
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
    proxy: {
      '/api/news': {
        target: 'https://cryptopanic.com',
        changeOrigin: true,
        secure: false,
        bypass: (req, res) => {
          // Custom handler to inject API key server-side
          const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
          if (!apiKey) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: 'API key missing' }));
            return;
          }

          // Construct the upstream URL
          const apiUrl = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
          
          // Fetch data server-side (Node.js)
          fetch(apiUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (compatible; OnChainStructuredProducts/1.0; +http://localhost:3000)'
            }
          })
          .then(async (response) => {
            if (!response.ok) {
              res.statusCode = response.status;
              res.end(JSON.stringify({ 
                error: `Upstream API error: ${response.statusText}`,
                blocked: response.status === 403
              }));
              return;
            }
            const data = await response.json();
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          })
          .catch((error) => {
            console.error('Proxy Error:', error);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: 'Internal proxy error' }));
          });

          // Return false to indicate we handled the request (or true to bypass standard proxying)
          // In this case, we handled it completely, so we return true to bypass the default proxy target
          return true; 
        }
      }
    }
  },
});
