console.log("ENV CHECK:", {
  exists: !!process.env.REACT_APP_CRYPTOPANIC_KEY,
  length: process.env.REACT_APP_CRYPTOPANIC_KEY?.length,
  prefix: process.env.REACT_APP_CRYPTOPANIC_KEY?.substring(0, 6)
});

console.log("VITE ENV CHECK:", {
  exists: !!process.env.VITE_CRYPTOPANIC_KEY,
  length: process.env.VITE_CRYPTOPANIC_KEY?.length,
  prefix: process.env.VITE_CRYPTOPANIC_KEY?.substring(0, 6)
});
