import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, TrendingUp, Lock, Zap, Users } from "lucide-react";
import { useState, useEffect } from "react";
import Glossary from "@/components/Glossary";
import NewsSection from "@/components/news/NewsSection";
import PriceTicker from "@/components/PriceTicker";

/**
 * Design Philosophy: Modern Fintech Minimalism
 * - Clean, spacious layouts with generous whitespace
 * - Hierarchical information architecture with clear visual progression
 * - Data-driven design with prominent metrics and statistics
 * - Deep slate blue (#1E3A5F) for stability, vibrant teal (#00D9FF) for innovation
 * - Asymmetric grid layouts avoiding generic centered designs
 */

export default function Home() {
  const [aum2024, setAum2024] = useState(0);
  const [aum2025, setAum2025] = useState(0);
  const [avgYield, setAvgYield] = useState(0);

  // Animate metrics on scroll
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Animate AUM 2024
          let current = 0;
          const interval = setInterval(() => {
            if (current < 17.5) {
              current += 0.5;
              setAum2024(parseFloat(current.toFixed(1)));
            } else {
              clearInterval(interval);
            }
          }, 20);

          // Animate AUM 2025
          let current2025 = 0;
          const interval2 = setInterval(() => {
            if (current2025 < 35) {
              current2025 += 1;
              setAum2025(parseFloat(current2025.toFixed(1)));
            } else {
              clearInterval(interval2);
            }
          }, 20);

          // Animate Average Yield
          let currentYield = 0;
          const interval3 = setInterval(() => {
            if (currentYield < 10.3) {
              currentYield += 0.2;
              setAvgYield(parseFloat(currentYield.toFixed(1)));
            } else {
              clearInterval(interval3);
            }
          }, 30);

          observer.unobserve(entry.target);
        }
      });
    });

    const metricsSection = document.getElementById("metrics-section");
    if (metricsSection) {
      observer.observe(metricsSection);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Price Ticker */}
      <PriceTicker />

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container py-4 flex items-center justify-between">
          <div className="fintech-heading text-2xl">On-Chain Structured Products</div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm">
              Learn
            </Button>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Explore
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: "url('/images/hero-background.jpg')",
          }}
        />
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 leading-tight">
                Democratizing Sophisticated Finance
              </h1>
              <p className="text-xl text-foreground/80 mb-8 leading-relaxed">
                On-chain structured products bring institutional-grade investment strategies to everyone. Transparent, automated, and accessible—all powered by blockchain technology.
              </p>
              <div className="flex gap-4">
                <Button className="fintech-button">
                  Get Started <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button variant="outline" className="fintech-button-secondary">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="animate-slide-in-right hidden md:block">
              <img
                src="/images/hero-background.jpg"
                alt="Blockchain Network"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* News Section */}
      <NewsSection />

      {/* Market Metrics Section */}
      <section id="metrics-section" className="py-20 bg-secondary/30">
        <div className="container">
          <h2 className="fintech-heading text-4xl mb-16 text-center">Market Growth in 2025</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="fintech-card p-8 text-center">
              <div className="metric-value mb-2">${aum2025.toFixed(1)}B</div>
              <div className="metric-label mb-4">Total AUM</div>
              <p className="text-sm text-foreground/70">On-chain asset management reached a critical inflection point</p>
            </Card>
            <Card className="fintech-card p-8 text-center">
              <div className="metric-value mb-2">+100%</div>
              <div className="metric-label mb-4">Year-over-Year Growth</div>
              <p className="text-sm text-foreground/70">Market size doubled from $17.5B in 2024</p>
            </Card>
            <Card className="fintech-card p-8 text-center">
              <div className="metric-value mb-2">{avgYield.toFixed(1)}%</div>
              <div className="metric-label mb-4">Average Gross APY</div>
              <p className="text-sm text-foreground/70">Structured products delivered strong yields</p>
            </Card>
          </div>
          <div className="mt-12 text-center">
            <img
              src="/images/market-growth-chart.png"
              alt="Market Growth Chart"
              className="rounded-lg shadow-lg mx-auto max-w-2xl"
            />
          </div>
        </div>
      </section>

      {/* Core Principles Section */}
      <section className="py-20">
        <div className="container">
          <h2 className="fintech-heading text-4xl mb-4">Core Principles</h2>
          <p className="text-lg text-foreground/70 mb-16 max-w-2xl">
            On-chain structured products operate on four foundational principles that distinguish them from traditional finance and simpler DeFi protocols.
          </p>
          <img
            src="/images/principles-illustration.png"
            alt="Core Principles"
            className="rounded-lg shadow-lg mb-16 w-full"
          />
          <div className="grid md:grid-cols-2 gap-8">
            <div className="fintech-card p-8">
              <div className="flex items-start gap-4">
                <Lock className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="fintech-subheading text-xl mb-3">Transparency & Verifiability</h3>
                  <p className="text-foreground/70">
                    Every rule, asset allocation, and transaction is recorded on a public ledger. Users can verify vault health and strategy execution in real-time without trusting intermediaries.
                  </p>
                </div>
              </div>
            </div>
            <div className="fintech-card p-8">
              <div className="flex items-start gap-4">
                <Users className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="fintech-subheading text-xl mb-3">Non-Custodial Management</h3>
                  <p className="text-foreground/70">
                    Users maintain ownership through smart contracts. No intermediary holds assets, eliminating counterparty risk and the need for traditional brokers.
                  </p>
                </div>
              </div>
            </div>
            <div className="fintech-card p-8">
              <div className="flex items-start gap-4">
                <Zap className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="fintech-subheading text-xl mb-3">Algorithmic Execution</h3>
                  <p className="text-foreground/70">
                    Strategies execute based on predefined code, removing emotional decision-making and ensuring consistent execution across market cycles.
                  </p>
                </div>
              </div>
            </div>
            <div className="fintech-card p-8">
              <div className="flex items-start gap-4">
                <TrendingUp className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="fintech-subheading text-xl mb-3">Efficiency Through Aggregation</h3>
                  <p className="text-foreground/70">
                    Pooled capital enables economies of scale, shared gas costs, and access to liquidity pools unavailable to individual traders.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container">
          <h2 className="fintech-heading text-4xl mb-16">How It Works</h2>
          <img
            src="/images/participation-flow.png"
            alt="Participation Flow"
            className="rounded-lg shadow-lg mb-16 w-full"
          />
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="fintech-subheading text-2xl mb-6">The Covered Call Strategy</h3>
              <p className="text-foreground/70 mb-4">
                The most popular on-chain structured product uses a covered call strategy to generate yield. Here's how it works:
              </p>
              <ol className="space-y-4 text-foreground/70">
                <li className="flex gap-3">
                  <span className="font-bold text-accent flex-shrink-0">1.</span>
                  <span>Deposit your ETH into a vault managed by protocols like Ribbon Finance</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-accent flex-shrink-0">2.</span>
                  <span>Every Friday, the vault auctions call options on the pooled ETH</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-accent flex-shrink-0">3.</span>
                  <span>Option buyers pay premiums; the vault collects these upfront</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-accent flex-shrink-0">4.</span>
                  <span>At week's end, if ETH stays below the strike price, the option expires worthless and you keep the premium</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-accent flex-shrink-0">5.</span>
                  <span>Premiums are automatically reinvested, compounding your returns</span>
                </li>
              </ol>
            </div>
            <div>
              <h3 className="fintech-subheading text-2xl mb-6">Key Benefits</h3>
              <div className="space-y-4">
                <div className="fintech-card-accent p-6">
                  <h4 className="font-semibold mb-2">Sustainable Yield</h4>
                  <p className="text-sm text-foreground/70">
                    Unlike yield farming dependent on inflationary tokens, structured products generate returns from actual market activity.
                  </p>
                </div>
                <div className="fintech-card-accent p-6">
                  <h4 className="font-semibold mb-2">Automated Management</h4>
                  <p className="text-sm text-foreground/70">
                    Smart contracts handle all execution. No need to actively manage positions or time the market.
                  </p>
                </div>
                <div className="fintech-card-accent p-6">
                  <h4 className="font-semibold mb-2">Institutional-Grade Access</h4>
                  <p className="text-sm text-foreground/70">
                    Strategies previously available only to institutional investors are now accessible to retail participants.
                  </p>
                </div>
                <div className="fintech-card-accent p-6">
                  <h4 className="font-semibold mb-2">Transparent Execution</h4>
                  <p className="text-sm text-foreground/70">
                    All strategy parameters and historical performance are verifiable on-chain, eliminating information asymmetry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Protocols Section */}
      <section className="py-20">
        <div className="container">
          <h2 className="fintech-heading text-4xl mb-16">Leading Protocols</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="fintech-card p-8">
              <h3 className="fintech-subheading text-2xl mb-3">Ribbon Finance</h3>
              <p className="text-foreground/70 mb-4">
                Pioneer in DeFi Option Vaults, offering automated options strategies on Ethereum, Avalanche, and Solana. Features algorithmic strike selection and open auctions.
              </p>
              <div className="text-sm text-accent font-semibold">→ Learn More</div>
            </div>
            <div className="fintech-card p-8">
              <h3 className="fintech-subheading text-2xl mb-3">Opyn</h3>
              <p className="text-foreground/70 mb-4">
                Provides the infrastructure layer for on-chain options, enabling custom options creation and trading. Powers many structured product protocols.
              </p>
              <div className="text-sm text-accent font-semibold">→ Learn More</div>
            </div>
            <div className="fintech-card p-8">
              <h3 className="fintech-subheading text-2xl mb-3">SynthBase</h3>
              <p className="text-foreground/70 mb-4">
                Focuses on structuring real-world assets (RWA) on-chain with tiered risk-return profiles. Emphasizes standardization and institutional-grade risk management.
              </p>
              <div className="text-sm text-accent font-semibold">→ Learn More</div>
            </div>
            <div className="fintech-card p-8">
              <h3 className="fintech-subheading text-2xl mb-3">Maple Finance</h3>
              <p className="text-foreground/70 mb-4">
                Specializes in institutional-grade structured credit, connecting borrowers and lenders through automated credit products with transparent underwriting.
              </p>
              <div className="text-sm text-accent font-semibold">→ Learn More</div>
            </div>
          </div>
        </div>
      </section>

      {/* Risk Considerations Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container">
          <h2 className="fintech-heading text-4xl mb-16">Risk Considerations</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="fintech-card p-8 border-l-4 border-l-accent">
              <h3 className="fintech-subheading text-lg mb-3">Smart Contract Risk</h3>
              <p className="text-foreground/70 text-sm mb-4">
                Bugs or exploits in smart contract code could impact funds.
              </p>
              <p className="text-accent text-sm font-semibold">Mitigation: Use audited protocols; start with small amounts</p>
            </div>
            <div className="fintech-card p-8 border-l-4 border-l-accent">
              <h3 className="fintech-subheading text-lg mb-3">Strategy Underperformance</h3>
              <p className="text-foreground/70 text-sm mb-4">
                Strategies may underperform in certain market conditions.
              </p>
              <p className="text-accent text-sm font-semibold">Mitigation: Diversify across multiple strategies</p>
            </div>
            <div className="fintech-card p-8 border-l-4 border-l-accent">
              <h3 className="fintech-subheading text-lg mb-3">Regulatory Risk</h3>
              <p className="text-foreground/70 text-sm mb-4">
                Regulatory changes could impact protocol operations.
              </p>
              <p className="text-accent text-sm font-semibold">Mitigation: Monitor regulatory developments</p>
            </div>
            <div className="fintech-card p-8 border-l-4 border-l-accent">
              <h3 className="fintech-subheading text-lg mb-3">Liquidity Risk</h3>
              <p className="text-foreground/70 text-sm mb-4">
                Difficulty withdrawing funds if protocol faces issues.
              </p>
              <p className="text-accent text-sm font-semibold">Mitigation: Avoid concentrating capital in one vault</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Explore On-Chain Structured Products?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Start with a reputable protocol, understand the strategy, and begin earning sustainable yields through transparent, automated investment strategies.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Get Started Today
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
            >
              Read Full Report
            </Button>
          </div>
        </div>
      </section>

      {/* Glossary Section */}
      <Glossary />

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="fintech-subheading mb-4">About</h4>
              <p className="text-foreground/70 text-sm">
                Comprehensive research on on-chain structured products and DeFi innovation.
              </p>
            </div>
            <div>
              <h4 className="fintech-subheading mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Full Report
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Protocols
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Glossary
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="fintech-subheading mb-4">Community</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Twitter
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Discord
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    GitHub
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="fintech-subheading mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Terms
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Disclaimer
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-foreground/70 text-sm">
            <p>© 2025 On-Chain Structured Products Research. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
