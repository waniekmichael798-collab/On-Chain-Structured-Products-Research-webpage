import { describe, it, expect } from 'vitest';

describe('CryptoPanic API v2', () => {
  it('should validate the API key against v2 endpoint', async () => {
    const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
    if (!apiKey) {
      throw new Error('VITE_CRYPTOPANIC_KEY is not set');
    }

    // Use the v2 endpoint as specified
    const response = await fetch(`https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true`);
    
    if (!response.ok) {
       // If 401 Unauthorized, the key is invalid
       if (response.status === 401) {
         throw new Error('Invalid API Key');
       }
       // Other errors might be network related or rate limits
       // We'll assume key is ok if not 401 for this check
    }
    
    const data = await response.json();
    // v2 response should have results
    expect(data).toHaveProperty('results');
  });
});
