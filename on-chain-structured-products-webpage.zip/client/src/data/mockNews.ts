import { NewsArticle } from "../hooks/useNewsData";

export const MOCK_NEWS: NewsArticle[] = [
  {
    id: 101,
    title: "Ribbon Finance Launches New Aevo Exchange for Options Trading",
    url: "https://ribbon.finance",
    domain: "ribbon.finance",
    source: { title: "Ribbon Finance", domain: "ribbon.finance" },
    published_at: new Date().toISOString(),
    category: "launch",
    votes: { positive: 10, negative: 1, important: 5 }
  },
  {
    id: 102,
    title: "DeFi TVL Surges Past $100B as Institutional Interest Grows",
    url: "https://defillama.com",
    domain: "defillama.com",
    source: { title: "DeFi Llama", domain: "defillama.com" },
    published_at: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    category: "market",
    votes: { positive: 15, negative: 2, important: 8 }
  },
  {
    id: 103,
    title: "Pendle Finance Raises $10M Series A to Expand Yield Trading",
    url: "https://pendle.finance",
    domain: "pendle.finance",
    source: { title: "Pendle", domain: "pendle.finance" },
    published_at: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
    category: "deal",
    votes: { positive: 20, negative: 0, important: 12 }
  },
  {
    id: 104,
    title: "New RWA Protocol Brings US Treasury Bills On-Chain",
    url: "https://coindesk.com",
    domain: "coindesk.com",
    source: { title: "CoinDesk", domain: "coindesk.com" },
    published_at: new Date(Date.now() - 18000000).toISOString(), // 5 hours ago
    category: "innovation",
    votes: { positive: 8, negative: 1, important: 4 }
  },
  {
    id: 105,
    title: "Ethereum Layer 2 Activity Reaches All-Time High",
    url: "https://l2beat.com",
    domain: "l2beat.com",
    source: { title: "L2Beat", domain: "l2beat.com" },
    published_at: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    category: "market",
    votes: { positive: 25, negative: 3, important: 15 }
  },
  {
    id: 106,
    title: "GMX V2 Introduces New Synthetic Assets and Lower Fees",
    url: "https://gmx.io",
    domain: "gmx.io",
    source: { title: "GMX", domain: "gmx.io" },
    published_at: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    category: "launch",
    votes: { positive: 12, negative: 2, important: 6 }
  }
];
