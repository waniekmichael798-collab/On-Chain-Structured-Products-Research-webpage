export const getHostname = (url: string): string => {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "Unknown Source";
  }
};
