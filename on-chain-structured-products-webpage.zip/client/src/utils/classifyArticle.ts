export type ArticleCategory = "deal" | "launch" | "market" | "innovation";

export const classifyArticle = (title: string): ArticleCategory => {
  const t = title.toLowerCase();
  if (/funding|raises|series [a-c]|acquisition|merger|investment|venture|backing/.test(t)) return "deal";
  if (/launch|announce|release|debut|goes live|mainnet|testnet|beta/.test(t)) return "launch";
  if (/tvl|regulation|sec|finma|market cap|volume|trend|correction|rally/.test(t)) return "market";
  if (/upgrade|v[2-9]|integration|partner|feature|update|protocol/.test(t)) return "innovation";
  return "market"; // default
};

export const categoryStyles: Record<ArticleCategory, string> = {
  deal: "bg-emerald-100 text-emerald-700",
  launch: "bg-purple-100 text-purple-700",
  market: "bg-blue-100 text-blue-700",
  innovation: "bg-amber-100 text-amber-700",
};
