import { useCryptoPrices } from "../hooks/useCryptoPrices";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function PriceTicker() {
  const { prices, isLoading, error } = useCryptoPrices();

  if (error) return null;

  // Duplicate prices to create seamless loop
  const displayPrices = [...prices, ...prices];

  return (
    <div className="w-full bg-slate-900 text-white border-b border-slate-800 overflow-hidden h-10 flex items-center relative z-50">
      {isLoading ? (
        <div className="container mx-auto px-4 flex items-center gap-4 text-xs text-slate-400">
          <span className="animate-pulse">Loading market data...</span>
        </div>
      ) : (
        <div className="flex items-center animate-scroll whitespace-nowrap hover:pause-animation">
          {displayPrices.map((coin, index) => (
            <div 
              key={`${coin.id}-${index}`} 
              className="flex items-center gap-2 px-6 border-r border-slate-800/50 text-xs font-medium"
            >
              <img src={coin.image} alt={coin.name} className="w-4 h-4 rounded-full" />
              <span className="uppercase text-slate-300">{coin.symbol}</span>
              <span>${coin.current_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              <span className={`flex items-center gap-0.5 ${
                coin.price_change_percentage_24h >= 0 ? "text-emerald-400" : "text-rose-400"
              }`}>
                {coin.price_change_percentage_24h >= 0 ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
