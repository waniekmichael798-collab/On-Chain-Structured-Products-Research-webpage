import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface GlossaryTerm {
  term: string;
  definition: string;
  category: "Core Concepts" | "Strategy" | "Market" | "Risk";
}

const glossaryTerms: GlossaryTerm[] = [
  {
    term: "On-Chain Structured Product",
    definition:
      "A blockchain-based financial instrument that derives its value from one or more underlying digital assets. Unlike simple tokens, these products are prepackaged investment strategies managed entirely by smart contracts, typically combining multiple assets with derivatives to achieve specific risk-return profiles.",
    category: "Core Concepts",
  },
  {
    term: "DeFi Option Vault (DOV)",
    definition:
      "A smart contract protocol that automates options strategies, allowing users to deposit assets and earn yields from option premiums without active management. The most prevalent form of on-chain structured products.",
    category: "Core Concepts",
  },
  {
    term: "Smart Contract Automation",
    definition:
      "The programmatic engine that executes trades, rolls over positions, and distributes yields according to predefined rules without human intervention. Ensures consistent execution across market cycles.",
    category: "Core Concepts",
  },
  {
    term: "Non-Custodial Management",
    definition:
      "A system where users maintain ownership of their funds through smart contracts rather than intermediaries holding assets. Eliminates counterparty risk and the need for traditional brokers.",
    category: "Core Concepts",
  },
  {
    term: "Composability",
    definition:
      "The 'money lego' property of DeFi, enabling structured product tokens to serve as collateral or building blocks in other protocols. Allows complex financial instruments to be combined and recombined.",
    category: "Core Concepts",
  },
  {
    term: "Real-World Assets (RWA)",
    definition:
      "Traditional financial assets (real estate, private credit, invoices) that are tokenized and integrated into on-chain structured formats. Represents the bridge between traditional finance and blockchain.",
    category: "Core Concepts",
  },
  {
    term: "Covered Call Strategy",
    definition:
      "An options strategy where the vault writes out-of-the-money call options while holding the underlying asset. Generates yield from option premiums while maintaining upside exposure (capped at the strike price).",
    category: "Strategy",
  },
  {
    term: "Put Selling Strategy",
    definition:
      "An options strategy where the vault writes out-of-the-money put options. Generates yield from option premiums by committing to buy the underlying asset at a predetermined price if the option is exercised.",
    category: "Strategy",
  },
  {
    term: "Strike Price",
    definition:
      "The predetermined price at which an option can be exercised. Critical to options strategy profitability—lower strike prices for puts mean cheaper options but higher likelihood of exercise.",
    category: "Strategy",
  },
  {
    term: "Option Premium",
    definition:
      "The price paid by option buyers for the right to purchase (call) or sell (put) the underlying asset. This is the primary source of yield in structured products.",
    category: "Strategy",
  },
  {
    term: "Epoch/Cycle",
    definition:
      "The time period (typically weekly) during which a strategy executes before rolling over to the next cycle. Most DOVs execute strategies on a fixed schedule, such as every Friday.",
    category: "Strategy",
  },
  {
    term: "Algorithmic Strike Selection",
    definition:
      "An automated process using on-chain data to determine the optimal price for writing options. Removes human bias and ensures consistent execution across market cycles.",
    category: "Strategy",
  },
  {
    term: "Total Value Locked (TVL)",
    definition:
      "The total amount of cryptocurrency deposited in a protocol or vault. A key metric for measuring protocol adoption and capital deployment.",
    category: "Market",
  },
  {
    term: "Assets Under Management (AUM)",
    definition:
      "The total value of assets managed by a protocol or strategy. In 2025, on-chain asset management reached $35 billion, representing 100% year-over-year growth.",
    category: "Market",
  },
  {
    term: "Annual Percentage Yield (APY)",
    definition:
      "The annualized return on an investment, accounting for compounding. Structured products in 2025 delivered average gross yields of 10.3% APY.",
    category: "Market",
  },
  {
    term: "Socialized Gas Costs",
    definition:
      "A mechanism where transaction fees (gas costs) are shared among all vault participants. Makes complex multi-transaction strategies economically viable for retail investors.",
    category: "Market",
  },
  {
    term: "Yield Farming",
    definition:
      "An early DeFi strategy where users earn returns by providing liquidity or staking tokens, often relying on inflationary token rewards. Less sustainable than structured product yields.",
    category: "Market",
  },
  {
    term: "Smart Contract Risk",
    definition:
      "The risk of bugs or exploits in smart contract code that could impact user funds. Mitigated through code audits and using established, battle-tested protocols.",
    category: "Risk",
  },
  {
    term: "Strategy Underperformance",
    definition:
      "The risk that a strategy may underperform in certain market conditions. For example, covered calls underperform in sharp bull markets when upside is capped.",
    category: "Risk",
  },
  {
    term: "Impermanent Loss",
    definition:
      "A loss that occurs when the underlying asset moves significantly in price, particularly relevant for strategies involving liquidity provision.",
    category: "Risk",
  },
  {
    term: "Regulatory Risk",
    definition:
      "The risk that regulatory changes could impact protocol operations or restrict access to on-chain structured products.",
    category: "Risk",
  },
  {
    term: "Liquidity Risk",
    definition:
      "The risk of difficulty withdrawing funds if a protocol faces issues or if market liquidity dries up.",
    category: "Risk",
  },
  {
    term: "Counterparty Risk",
    definition:
      "The risk that an intermediary (bank, broker) fails to fulfill its obligations. Eliminated in non-custodial on-chain products.",
    category: "Risk",
  },
  {
    term: "Transparency",
    definition:
      "A core principle of on-chain structured products where every rule, asset allocation, and transaction is recorded on a public ledger, enabling real-time verification.",
    category: "Core Concepts",
  },
  {
    term: "Decentralized Finance (DeFi)",
    definition:
      "Financial services built on blockchain technology that operate without traditional intermediaries. On-chain structured products are a key component of the DeFi ecosystem.",
    category: "Core Concepts",
  },
];

export default function Glossary() {
  const [expandedTerms, setExpandedTerms] = useState<Set<string>>(new Set());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const toggleTerm = (term: string) => {
    const newExpanded = new Set(expandedTerms);
    if (newExpanded.has(term)) {
      newExpanded.delete(term);
    } else {
      newExpanded.add(term);
    }
    setExpandedTerms(newExpanded);
  };

  const categories = Array.from(new Set(glossaryTerms.map((t) => t.category)));
  const filteredTerms = selectedCategory
    ? glossaryTerms.filter((t) => t.category === selectedCategory)
    : glossaryTerms;

  return (
    <section className="py-20">
      <div className="container">
        <h2 className="fintech-heading text-4xl mb-4">Glossary</h2>
        <p className="text-lg text-foreground/70 mb-12 max-w-2xl">
          A comprehensive guide to key terms and concepts related to on-chain structured products. Click any term to expand its definition.
        </p>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 mb-12">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
              selectedCategory === null
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground border border-border hover:bg-secondary/80"
            }`}
          >
            All Terms
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                selectedCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground border border-border hover:bg-secondary/80"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Glossary Terms */}
        <div className="space-y-3">
          {filteredTerms.map((item) => (
            <div
              key={item.term}
              className="fintech-card overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => toggleTerm(item.term)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-secondary/50 transition-colors duration-200"
              >
                <div className="flex items-center gap-4 flex-1 text-left">
                  <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs font-semibold rounded-full">
                    {item.category}
                  </span>
                  <h3 className="fintech-subheading text-lg">{item.term}</h3>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-accent flex-shrink-0 transition-transform duration-300 ${
                    expandedTerms.has(item.term) ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Expanded Definition */}
              {expandedTerms.has(item.term) && (
                <div className="px-6 py-4 bg-secondary/30 border-t border-border animate-fade-in-up">
                  <p className="text-foreground/80 leading-relaxed">{item.definition}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredTerms.length === 0 && (
          <div className="text-center py-12">
            <p className="text-foreground/70">No terms found in this category.</p>
          </div>
        )}

        {/* Statistics */}
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          <div className="fintech-card p-6 text-center">
            <div className="metric-value mb-2">{glossaryTerms.length}</div>
            <div className="metric-label">Total Terms</div>
          </div>
          <div className="fintech-card p-6 text-center">
            <div className="metric-value mb-2">{categories.length}</div>
            <div className="metric-label">Categories</div>
          </div>
          <div className="fintech-card p-6 text-center">
            <div className="metric-value mb-2">100%</div>
            <div className="metric-label">Coverage</div>
          </div>
        </div>
      </div>
    </section>
  );
}
