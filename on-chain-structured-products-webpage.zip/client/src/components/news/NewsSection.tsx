import { useState } from "react";
import { RefreshCw, AlertCircle, AlertTriangle, Info } from "lucide-react";
import { useNewsData } from "../../hooks/useNewsData";
import NewsCard from "./NewsCard";
import FilterTabs from "./FilterTabs";
import NewsLoadingState from "./NewsLoadingState";

export default function NewsSection() {
  const { 
    articles, 
    isLoading, 
    error, 
    lastUpdated, 
    refresh, 
    isRateLimited, 
    isFallbackMode,
    loadMore,
    hasMore
  } = useNewsData();
  
  const [activeFilter, setActiveFilter] = useState("all");
  const [visibleCount, setVisibleCount] = useState(6);

  const filteredArticles = activeFilter === "all"
    ? articles
    : articles.filter(article => article.category === activeFilter);

  const displayedArticles = filteredArticles.slice(0, visibleCount);
  
  // If filtering locally, we handle "load more" by just showing more from the already fetched list
  // unless we are at the end of the list, then we might need to fetch more from API if supported
  // But per spec, "Load More" uses `next` URL.
  // Since we filter client-side, the "next" page might contain relevant articles.
  // For simplicity in this UI, we'll just show more of what we have, and trigger API load more if needed.
  
  const handleLoadMore = () => {
    if (visibleCount < filteredArticles.length) {
      setVisibleCount(prev => prev + 6);
    } else if (hasMore) {
      loadMore();
    }
  };

  const showLoadMore = visibleCount < filteredArticles.length || hasMore;

  return (
    <section className="w-full py-12 px-4 md:px-8 bg-slate-50 border-b border-slate-200">
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-slate-900">Latest from DeFi & Structured Products</h2>
            <span className="flex items-center gap-1.5 text-sm text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              Live
            </span>
          </div>
          
          <div className="flex items-center gap-3 text-sm text-slate-500">
            {lastUpdated && (
              <span>Updated {new Date(lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            )}
            <button 
              onClick={refresh}
              disabled={isLoading}
              className="p-2 hover:bg-slate-200 rounded-full transition-colors disabled:opacity-50"
              title="Refresh news"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Rate Limit Banner */}
        {isRateLimited && (
          <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-lg text-sm mb-6 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            <span>Live updates paused due to rate limits. Showing recent results.</span>
          </div>
        )}

        {/* Fallback Banner */}
        {isFallbackMode && !isRateLimited && (
          <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg text-sm mb-6 flex items-center gap-2">
            <Info className="w-4 h-4" />
            <span><strong>Demo Mode:</strong> Live news feed is unavailable in this environment. Showing sample structured products data.</span>
          </div>
        )}

        {/* Error Banner */}
        {error && !isRateLimited && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg text-sm mb-6 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>Updates temporarily unavailable. {articles.length > 0 ? "Showing cached results." : "Please try again later."}</span>
          </div>
        )}

        {/* Filter Tabs */}
        <FilterTabs activeFilter={activeFilter} onFilterChange={setActiveFilter} />

        {/* Content */}
        {isLoading && articles.length === 0 ? (
          <NewsLoadingState />
        ) : filteredArticles.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {displayedArticles.map((article) => (
                <NewsCard key={article.id} article={article} />
              ))}
            </div>
            
            {showLoadMore && (
              <div className="flex justify-center">
                <button
                  onClick={handleLoadMore}
                  disabled={isLoading}
                  className="px-6 py-2 bg-white border border-slate-300 text-slate-700 font-medium rounded-lg hover:bg-slate-50 transition-colors shadow-sm disabled:opacity-50 flex items-center gap-2"
                >
                  {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : null}
                  Load More News
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-12 text-slate-500 bg-white rounded-xl border border-slate-200 border-dashed">
            <p>No news matching this filter right now.</p>
            <button 
              onClick={() => setActiveFilter("all")}
              className="mt-2 text-blue-600 hover:underline font-medium"
            >
              View all news
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
