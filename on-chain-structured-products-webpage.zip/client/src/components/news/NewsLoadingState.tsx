export default function NewsLoadingState() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="p-4 bg-white rounded-xl border border-slate-200 h-32 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-4 h-4 bg-slate-200 rounded animate-pulse"></div>
            <div className="w-20 h-3 bg-slate-200 rounded animate-pulse"></div>
          </div>
          <div className="w-full h-4 bg-slate-200 rounded mb-2 animate-pulse"></div>
          <div className="w-2/3 h-4 bg-slate-200 rounded mb-auto animate-pulse"></div>
          <div className="w-16 h-5 bg-slate-200 rounded-full animate-pulse mt-2"></div>
        </div>
      ))}
    </div>
  );
}
