import { NewsArticle } from "../../hooks/useNewsData";
import { formatRelativeTime } from "../../utils/formatRelativeTime";
import { categoryStyles } from "../../utils/classifyArticle";

interface NewsCardProps {
  article: NewsArticle;
}

export default function NewsCard({ article }: NewsCardProps) {
  return (
    <a 
      href={article.url} 
      target="_blank" 
      rel="noopener noreferrer"
      className="block p-4 bg-white rounded-xl border border-slate-200 hover:shadow-md hover:border-slate-300 transition-all h-full flex flex-col"
    >
      <div className="flex items-center gap-2 mb-2">
        <img 
          src={`https://logo.clearbit.com/${article.domain}`} 
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://via.placeholder.com/16?text=?";
          }}
          className="w-4 h-4 rounded" 
          alt={article.source.title}
        />
        <span className="text-xs text-slate-500 truncate max-w-[100px]">{article.source.title}</span>
        <span className="text-xs text-slate-400">•</span>
        <span className="text-xs text-slate-400">{formatRelativeTime(article.published_at)}</span>
      </div>
      
      <h3 className="font-medium text-slate-900 mb-3 line-clamp-2 flex-grow">
        {article.title}
      </h3>
      
      <div>
        <span className={`inline-block px-2 py-0.5 text-xs rounded-full font-medium ${categoryStyles[article.category]}`}>
          {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
        </span>
      </div>
    </a>
  );
}
