import { useState, useEffect, useCallback } from "react";
import { classifyArticle, ArticleCategory } from "../utils/classifyArticle";
import { getHostname } from "../utils/getHostname";
import { MOCK_NEWS } from "../data/mockNews";

export interface NewsArticle {
  id: number;
  title: string;
  url: string;
  domain: string;
  source: { title: string; domain: string };
  published_at: string;
  category: ArticleCategory;
  votes: { positive: number; negative: number; important: number };
}

const PRIMARY_TERMS = [
  "structured product", "option vault", "dov", "tokenized",
  "rwa", "yield vault", "tranche", "ribbon", "aevo", "pendle",
  "tranchess", "eigenlayer", "ethena", "liquid staking"
];

const SECONDARY_TERMS = [
  "defi yield", "tvl", "funding round", "raises", "series a",
  "series b", "acquisition", "merger", "launches", "mainnet"
];

const CACHE_KEY = "cryptopanic_news";
const CACHE_TTL = 600000; // 10 minutes

export const useNewsData = () => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [isRateLimited, setIsRateLimited] = useState(false);
  const [isFallbackMode, setIsFallbackMode] = useState(false);
  const [nextPageUrl, setNextPageUrl] = useState<string | null>(null);

  const isRelevant = (title: string) => {
    const t = title.toLowerCase();
    return PRIMARY_TERMS.some(term => t.includes(term)) ||
           SECONDARY_TERMS.some(term => t.includes(term));
  };

  const sortByQuality = (articles: NewsArticle[]) => {
    return articles.sort((a, b) => {
      const scoreA = a.votes.important * 3 + a.votes.positive;
      const scoreB = b.votes.important * 3 + b.votes.positive;
      return scoreB - scoreA;
    });
  };

  const processArticles = (results: any[]) => {
    return results.map((item: any) => ({
      id: item.id,
      title: item.title,
      url: item.original_url || item.url, // Use original_url if available
      domain: item.source?.domain || getHostname(item.url),
      source: item.source || { title: getHostname(item.url), domain: getHostname(item.url) },
      published_at: item.published_at,
      category: classifyArticle(item.title),
      votes: item.votes
    }));
  };

  const fetchNews = useCallback(async (url?: string) => {
    setIsLoading(true);
    setError(null);
    setIsRateLimited(false);

    // Check cache first if not loading more
    if (!url) {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const { data, timestamp, next } = JSON.parse(cached);
        if (Date.now() - timestamp < CACHE_TTL) {
          setArticles(data);
          setLastUpdated(timestamp);
          setNextPageUrl(next);
          setIsLoading(false);
          return;
        }
      }
    }

    try {
      const apiKey = import.meta.env.VITE_CRYPTOPANIC_KEY;
      if (!apiKey) {
        throw new Error("API key not configured");
      }

      let data;
      
      // Try fetching from our own secure backend first (Vercel function or local Express route)
      try {
        const backendUrl = url || '/api/news';
        const response = await fetch(backendUrl);
        
        if (response.ok) {
          data = await response.json();
          // Check if the backend reported a block even with 200 OK (or if we need to inspect the body)
          // But usually we return non-200 for errors. 
          // If the backend returns a JSON with "blocked": true, we should throw to trigger fallback.
          if (data.blocked) {
             throw new Error("Backend reported upstream block");
          }
        } else {
          // If response is not OK, check if it's a block
          const errorData = await response.json().catch(() => ({}));
          if (errorData.blocked || response.status === 403) {
             throw new Error("Backend blocked by upstream");
          }
          throw new Error(`Backend fetch failed: ${response.status}`);
        }
      } catch (backendError) {
        console.warn("Backend fetch failed, falling back to proxy:", backendError);
        
        // Fallback: Use proxy to bypass CORS if backend fails (e.g. in static preview without server)
        const apiUrl = url || `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
        const targetUrl = encodeURIComponent(apiUrl);
        
        try {
          const response = await fetch(`https://corsproxy.io/?${targetUrl}`);

          if (!response.ok) {
            throw new Error(`Proxy failed: ${response.status}`);
          }
          data = await response.json();
        } catch (proxyError) {
          console.warn("Client-side proxy failed, falling back to mock data:", proxyError);
          // Final Fallback: Use Mock Data
          // This ensures the UI works even in strict environments (like sandbox) where all proxies are blocked
          data = { results: MOCK_NEWS, next: null };
          setIsFallbackMode(true);
        }
      }

      // Check if the API returned an error inside the JSON (some APIs return 200 with error body)
      if (data.detail && data.detail.includes("throttled")) {
        // Rate limited
        const cached = localStorage.getItem(CACHE_KEY);
        if (cached) {
          const { data: cachedData, timestamp, next } = JSON.parse(cached);
          setArticles(cachedData);
          setLastUpdated(timestamp);
          setNextPageUrl(next);
          setIsRateLimited(true);
        }
        return;
      }

      if (!data.results) {
        throw new Error("Invalid data format");
      }

      const processed = processArticles(data.results);
      
      // Filter logic
      let filtered = processed.filter((a: NewsArticle) => isRelevant(a.title));
      
      // Fallback logic
      if (filtered.length < 3) {
        setIsFallbackMode(true);
        filtered = sortByQuality(processed); // Show all, sorted by quality
      } else {
        setIsFallbackMode(false);
        filtered = sortByQuality(filtered);
      }

      if (url) {
        // Appending data (Load More)
        setArticles(prev => [...prev, ...filtered]);
      } else {
        // New fetch
        setArticles(filtered);
        setLastUpdated(Date.now());
        
        // Update cache
        localStorage.setItem(CACHE_KEY, JSON.stringify({
          data: filtered,
          timestamp: Date.now(),
          next: data.next
        }));
      }
      
      setNextPageUrl(data.next);

    } catch (err) {
      console.error("Error fetching news:", err);
      // Network error or other issue - use cache silently
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const { data, timestamp, next } = JSON.parse(cached);
        setArticles(data);
        setLastUpdated(timestamp);
        setNextPageUrl(next);
        // Don't set error state to keep UI clean, just log it
      } else {
        setError(err instanceof Error ? err.message : "An unknown error occurred");
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchNews();
    
    // Auto-refresh every 10 minutes
    const intervalId = setInterval(() => fetchNews(), CACHE_TTL);
    
    return () => clearInterval(intervalId);
  }, [fetchNews]);

  const loadMore = () => {
    if (nextPageUrl) {
      fetchNews(nextPageUrl);
    }
  };

  return { 
    articles, 
    isLoading, 
    error, 
    lastUpdated, 
    refresh: () => fetchNews(), 
    isRateLimited,
    isFallbackMode,
    loadMore,
    hasMore: !!nextPageUrl
  };
};
