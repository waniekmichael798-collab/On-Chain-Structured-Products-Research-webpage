// Simulate the environment variable as it would be in the app (using VITE_ prefix as confirmed in previous step)
process.env.VITE_CRYPTOPANIC_KEY = "a995abdab0baff97b69234d859877f8e783994e8";

// Code mirrored from useNewsData.ts (but using process.env for this standalone test)
const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
const constructedURL = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;

console.log("CONSTRUCTED URL:", constructedURL);
console.log("URL LENGTH:", constructedURL.length);

// Verify against requirements
const requirements = {
  baseUrl: constructedURL.startsWith("https://cryptopanic.com/api/developer/v2/posts/"),
  protocol: constructedURL.startsWith("https"),
  path: constructedURL.includes("/api/developer/v2/posts/"),
  authToken: constructedURL.includes(`auth_token=${apiKey}`)
};

console.log("REQUIREMENTS CHECK:", requirements);
