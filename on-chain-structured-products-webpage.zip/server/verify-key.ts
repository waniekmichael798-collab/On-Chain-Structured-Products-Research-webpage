// Load environment variables from .env if available (though in this env they are injected)
import { config } from 'dotenv';
config();

// Check for both VITE_ prefixed key (standard for Vite) and non-prefixed (if set that way)
const key = process.env.VITE_CRYPTOPANIC_KEY || process.env.CRYPTOPANIC_KEY;

console.log("Server key exists:", !!key);
console.log("Key length:", key?.length); // Expect: 40
console.log("Key source:", process.env.VITE_CRYPTOPANIC_KEY ? "VITE_CRYPTOPANIC_KEY" : "CRYPTOPANIC_KEY");
