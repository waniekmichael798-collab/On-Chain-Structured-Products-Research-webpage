import { describe, it, expect } from 'vitest';

describe('Local Proxy Integration', () => {
  it('should successfully fetch news via the local proxy endpoint', async () => {
    // Test against the running dev server
    const proxyUrl = 'http://localhost:3000/api/news';
    
    try {
      const response = await fetch(proxyUrl);
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Proxy request failed with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      // Verify structure of response
      expect(data).toHaveProperty('count');
      expect(data).toHaveProperty('results');
      expect(Array.isArray(data.results)).toBe(true);
      
      console.log('Successfully fetched', data.results.length, 'news items via proxy');
    } catch (error) {
      console.error('Proxy Test Failed:', error);
      throw error;
    }
  });
});
