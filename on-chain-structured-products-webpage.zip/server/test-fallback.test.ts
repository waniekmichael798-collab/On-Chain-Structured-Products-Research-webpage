import { describe, it, expect } from 'vitest';
import { config } from 'dotenv';

config();

describe('Client-Side Proxy Fallback Check', () => {
  it('should successfully fetch news via corsproxy.io', async () => {
    const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
    if (!apiKey) throw new Error("API key missing");

    const targetUrl = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
    const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
    
    console.log("Testing Fallback URL:", proxyUrl);

    try {
      const response = await fetch(proxyUrl);
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Fallback proxy failed with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      // Verify structure
      expect(data).toHaveProperty('results');
      console.log('SUCCESS: Fallback proxy fetched', data.results?.length, 'items');
      
      // Check if we have enough items
      if (data.results && data.results.length > 0) {
          console.log('Sample item title:', data.results[0].title);
      } else {
          console.warn('WARNING: Fallback proxy returned 0 items');
      }

    } catch (error) {
      console.error('Fallback Test Failed:', error);
      throw error;
    }
  });
});
