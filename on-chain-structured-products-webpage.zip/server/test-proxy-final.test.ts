import { describe, it, expect } from 'vitest';

describe('Local Proxy Integration (Final Check)', () => {
  it('should attempt to fetch news via the local proxy endpoint', async () => {
    // Test against the running dev server
    const proxyUrl = 'http://localhost:3000/api/news';
    
    try {
      const response = await fetch(proxyUrl);
      
      // If we get a 200 OK, great!
      if (response.ok) {
        const data = await response.json();
        expect(data).toHaveProperty('results');
        console.log('SUCCESS: Proxy fetched data successfully (200 OK)');
        return;
      }

      // If we get a 403, check if it's our handled "blocked" response
      if (response.status === 403) {
        const data = await response.json();
        if (data.blocked === true) {
           console.log('SUCCESS: Proxy is working but upstream blocked the IP (Expected in Sandbox)');
           console.log('Proxy correctly returned structured error:', JSON.stringify(data));
           return;
        }
      }

      // Any other error is a failure
      const errorText = await response.text();
      throw new Error(`Proxy failed with unexpected status ${response.status}: ${errorText}`);

    } catch (error) {
      console.error('Proxy Test Failed:', error);
      throw error;
    }
  });
});
