import { describe, it, expect } from 'vitest';
import { config } from 'dotenv';

// Load environment variables
config();

describe('CryptoPanic API Integration', () => {
  it('should successfully fetch news with the provided API key', async () => {
    const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
    
    if (!apiKey) {
      throw new Error('VITE_CRYPTOPANIC_KEY is not set in environment variables');
    }

    console.log('Testing with API Key length:', apiKey.length);

    const apiUrl = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
    
    try {
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API request failed with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      // Verify structure of response
      expect(data).toHaveProperty('count');
      expect(data).toHaveProperty('results');
      expect(Array.isArray(data.results)).toBe(true);
      
      console.log('Successfully fetched', data.results.length, 'news items');
    } catch (error) {
      console.error('API Test Failed:', error);
      throw error;
    }
  });
});
