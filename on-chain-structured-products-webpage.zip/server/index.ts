import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Local API proxy for development/sandbox (mirrors Vercel function)
  app.get("/api/news", async (_req, res) => {
    const apiKey = process.env.VITE_CRYPTOPANIC_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "API key missing" });
    }
    try {
      const apiUrl = `https://cryptopanic.com/api/developer/v2/posts/?auth_token=${apiKey}&public=true&filter=rising&kind=news&regions=en`;
      
      // Add User-Agent to try to bypass basic bot detection
      const response = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; OnChainStructuredProducts/1.0; +http://localhost:3000)'
        }
      });
      
      if (!response.ok) {
        // If blocked by Cloudflare (403) or other issues, return error to trigger frontend fallback
        console.warn(`Upstream API error: ${response.status} ${response.statusText}`);
        return res.status(response.status).json({ 
          error: `Upstream API error: ${response.statusText}`,
          blocked: response.status === 403 // Flag to indicate potential blocking
        });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Local API Error:", error);
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
